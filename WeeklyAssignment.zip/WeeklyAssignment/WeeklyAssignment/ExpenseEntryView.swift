//
//  ExpenseEntryView.swift
//  WeeklyAssignment
//
//  Created by Rawan on 08/09/1446 AH.
//

import SwiftUI

struct ExpenseEntryView: View {
    @ObservedObject var viewModel: ExpenseViewModel
    @State private var name: String = ""
    @State private var amount: String = ""
    @State private var selectedCategory: ExpenseCategory = .food

    var body: some View {
        //here im using vstack to show the text fileds under each other
        VStack(spacing: 15) {
            TextField("Expense Name", text: $name)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()

            TextField("Amount", text: $amount)
                .keyboardType(.decimalPad)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
// here i have a picker to pick from the categories i have
            Picker("Category", selection: $selectedCategory) {
                ForEach(ExpenseCategory.allCases, id: \.self) { category in
                    Text(category.rawValue).tag(category)
                }
            }
            .pickerStyle(SegmentedPickerStyle())
            .padding()
// i have a buttom and called addExpense funtion
            Button(action: {
                withAnimation(.spring(response: 0.4, dampingFraction: 0.6)) {
                    addExpense()
                }
            }) {
                Text("Add Expense")
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.purple.opacity(0.5))
                    .cornerRadius(8)
                    .shadow(radius: 0.9)
            }
            .padding()
        }
    }
//add funtion 
    private func addExpense() {
        guard let amountValue = Double(amount) else { return }
        viewModel.addExpense(name: name, amount: amountValue, category: selectedCategory)
        name = ""
        amount = ""
    }
}
