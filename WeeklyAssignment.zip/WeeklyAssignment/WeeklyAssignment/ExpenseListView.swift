//
//  ExpenseListView.swift
//  WeeklyAssignment
//
//  Created by Rawan on 08/09/1446 AH.
//

import SwiftUI

struct ExpenseListView: View {
    @ObservedObject var viewModel: ExpenseViewModel
    @State private var selectedCategory: ExpenseCategory? = nil
//it will filter the displayed list according to the categires chosen
    var filteredExpenses: [Expense] {
        if let category = selectedCategory {
            return viewModel.expenses.filter { $0.category == category }
        }
        return viewModel.expenses
    }

    var body: some View {
        VStack {
            //using picker to pick one of the cantigores we have
            Picker("Filter", selection: $selectedCategory) {
                Text("All").tag(nil as ExpenseCategory?)
                ForEach(ExpenseCategory.allCases, id: \.self) { category in
                    Text(category.rawValue).tag(category as ExpenseCategory?)
                }
            }
            .pickerStyle(MenuPickerStyle())
            .padding()

            List(filteredExpenses) { expense in
                HStack {
                    VStack(alignment: .leading) {
                        Text(expense.name).font(.headline)
                        Text(expense.category.rawValue).font(.subheadline).foregroundColor(.gray)
                    }
                    Spacer()
                    Text(String(format: "$%.2f", expense.amount))
                }
            }
        }
    }
}
