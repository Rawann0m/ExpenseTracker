//
//  Expense.swift
//  WeeklyAssignment
//
//  Created by Rawan on 08/09/1446 AH.
//

import Foundation
//enum for the categires
enum ExpenseCategory: String, CaseIterable, Codable {
    case food = "Food"
    case travel = "Travel"
    case shopping = "Shopping"
    case other = "Other"
}
// the structure for the expenses
struct Expense: Identifiable, Codable {
    var id = UUID()
    var name: String
    var amount: Double
    var category: ExpenseCategory
}
