//
//  ContentView.swift
//  WeeklyAssignment
//
//  Created by Rawan on 08/09/1446 AH.
//

import SwiftUI

struct ContentView: View {
    @StateObject var viewModel = ExpenseViewModel()
    @Binding var isDarkMode: Bool

    var body: some View {
        ZStack{
            NavigationView {
                //using vstack ti show them under each other
                VStack {
                    ExpenseEntryView(viewModel: viewModel)
                    ExpenseListView(viewModel: viewModel)
                    //dark mood toggle
                    Toggle("Dark Mode", isOn: $isDarkMode)
                                        .padding()
                }
                .navigationTitle("Expense Tracker")
            }
        }
    }
}


#Preview {
    DarkMoodView()
}
