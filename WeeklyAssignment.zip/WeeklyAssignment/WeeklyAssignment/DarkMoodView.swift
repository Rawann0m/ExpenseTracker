//
//  DarkMoodView.swift
//  WeeklyAssignment
//
//  Created by Rawan on 10/09/1446 AH.
//

import SwiftUI

struct DarkMoodView: View {
    @State private var isDarkMode = false

    var body: some View {
        ContentView(isDarkMode: $isDarkMode)
            .preferredColorScheme(isDarkMode ? .dark : .light)
    }
}
