//
//  ExpenseViewModel.swift
//  WeeklyAssignment
//
//  Created by Rawan on 08/09/1446 AH.
//

import Foundation

class ExpenseViewModel: ObservableObject {
    @Published var expenses: [Expense] = []
//here is the view model 
    func addExpense(name: String, amount: Double, category: ExpenseCategory) {
        let newExpense = Expense(name: name, amount: amount, category: category)
        expenses.append(newExpense)
    }
}
