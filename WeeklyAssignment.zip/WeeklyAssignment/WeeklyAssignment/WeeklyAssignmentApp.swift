//
//  WeeklyAssignmentApp.swift
//  WeeklyAssignment
//
//  Created by Rawan on 08/09/1446 AH.
//

import SwiftUI

@main
struct WeeklyAssignmentApp: App {
    var body: some Scene {
        WindowGroup {
            DarkMoodView()
        }
    }
}
